import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'bd-button',
  templateUrl: './bd-button.component.html',
  styleUrls: ['./bd-button.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BdButtonComponent {

  @Input() disabled = false;
  @Input() type: 'button' | 'submit' = 'button';

}