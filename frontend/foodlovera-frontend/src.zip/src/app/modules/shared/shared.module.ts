import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';

import { BdButtonComponent } from './bd-button/bd-button.component';

@NgModule({
  declarations: [
    BdButtonComponent
  ],
  imports: [
    CommonModule,
    TranslateModule
  ],
  exports: [
    // ca să ai acces la *ngIf, *ngFor, pipes etc
    CommonModule,
    // ca să meargă | translate oriunde importă SharedModule
    TranslateModule,

    // componenta reutilizabilă
    BdButtonComponent
  ]
})
export class SharedModule {}