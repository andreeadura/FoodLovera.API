import { Component, ChangeDetectionStrategy } from '@angular/core';
import { Observable } from 'rxjs';
import { ImageConfigService } from '../../core/services/imageConfig.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HomepageComponent {
  readonly heroBg$: Observable<string>;

  constructor(private readonly images: ImageConfigService) {
    this.heroBg$ = this.images.get$('home', 'heroBackground1');
  }

  createRoom(): void {
    // pasul următor: navigare către create-session
    console.log('create room');
  }

  joinRoom(): void {
    // pasul următor: navigare către join-session
    console.log('join room');
  }
}