import { ApplicationConfig, isDevMode, importProvidersFrom } from '@angular/core';
import { provideRouter } from '@angular/router';
import { HttpClient, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';

import { routes } from './app.routes';

import { provideStore, provideState } from '@ngrx/store';
import { provideEffects } from '@ngrx/effects';
import { provideStoreDevtools } from '@ngrx/store-devtools';

import { authFeatureKey, authReducer } from './modules/auth/store/reducer/auth.reducer';
import { AuthEffects } from './modules/auth/store/effects/auth.effects';

import { sessionsFeatureKey, sessionsReducer } from './modules/sessions/store/reducer/sessions.reducer';
import { SessionsEffects } from './modules/sessions/store/effects/sessions.effects';

import { adminFeatureKey, adminReducer } from './modules/admin/store/reducer/admin.reducer';
import { AdminEffects } from './modules/admin/store/effects/admin.effects';

import { userFeatureKey, userReducer } from './modules/user/store/reducer/user.reducer';
import { UserEffects } from './modules/user/store/effects/user.effects';

import { Observable } from 'rxjs';
import { TranslateLoader, TranslateModule, TranslationObject } from '@ngx-translate/core';

class SimpleJsonTranslateLoader implements TranslateLoader {
  constructor(
    private readonly http: HttpClient,
    private readonly prefix = '/assets/translations/',
    private readonly suffix = '.json'
  ) {}

  getTranslation(lang: string): Observable<TranslationObject> {
    return this.http.get<TranslationObject>(`${this.prefix}${lang}${this.suffix}`);
  }
}

export function translateLoaderFactory(http: HttpClient): TranslateLoader {
  return new SimpleJsonTranslateLoader(http);
}

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(withInterceptorsFromDi()),

    // Translations (RO/EN)
    importProvidersFrom(
      TranslateModule.forRoot({
        defaultLanguage: 'ro',
        useDefaultLang: true,
        loader: {
          provide: TranslateLoader,
          useFactory: translateLoaderFactory,
          deps: [HttpClient],
        },
      })
    ),

    // Root store
    provideStore(),

    // Feature states
    provideState(authFeatureKey, authReducer),
    provideState(sessionsFeatureKey, sessionsReducer),
    provideState(adminFeatureKey, adminReducer),
    provideState(userFeatureKey, userReducer),

    // Effects
    provideEffects(AuthEffects, SessionsEffects, AdminEffects, UserEffects),

    // DevTools (doar în dev)
    provideStoreDevtools({
      maxAge: 25,
      logOnly: !isDevMode(),
    }),
  ],
};